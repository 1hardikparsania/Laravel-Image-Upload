 
<?php $__env->startSection('content'); ?>
 
    <br>
    <?php if(count($errors) > 0): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
 
    <h1 class="title"> Create Cars </h1>
 
    <form method="POST" action="/uploadsql" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
 
        <div class="field">
 
            <label class="lable" for="name">Car Name </label>
 
            <div class="control">
 
                <input type="text" class="input" name="imagename" placeholder="Title" value="" required>
        
            </div>
       
        </div>
    
        <div class="field">
 
            <div class="control">
                 <input type="file" class="form-control-file" name="fileToUpload" aria-describedby="fileHelp">
            </div>
         </div>   
       
        <div class="field">
 
            <div class="control">
 
                <button type="submit" class="button is-link">Create Car</button>
 
            </div>
 
        </div>
 
    </form> 
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraImageUpload57/laraimageupload57/resources/views/uploadimage.blade.php ENDPATH**/ ?>